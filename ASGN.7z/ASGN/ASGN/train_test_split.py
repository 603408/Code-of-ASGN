import os
import shutil
from sklearn.model_selection import train_test_split

# 路径设置
data_dir = 'data/ceramic visual pattern/images'
train_dir = 'data/ceramic visual pattern/train'
val_dir = 'data/ceramic visual pattern/valid'
test_dir = 'data/ceramic visual pattern/test'

# 创建训练集、验证集和测试集文件夹
if not os.path.exists(train_dir):
    os.makedirs(train_dir)
if not os.path.exists(val_dir):
    os.makedirs(val_dir)
if not os.path.exists(test_dir):
    os.makedirs(test_dir)

# 获取所有类别的文件夹名
categories = [category for category in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, category))]

# 对每个类别的图片进行分割
for category in categories:
    # 创建对应于类别的训练集、验证集和测试集文件夹
    train_category_dir = os.path.join(train_dir, category)
    val_category_dir = os.path.join(val_dir, category)
    test_category_dir = os.path.join(test_dir, category)

    if not os.path.exists(train_category_dir):
        os.makedirs(train_category_dir)
    if not os.path.exists(val_category_dir):
        os.makedirs(val_category_dir)
    if not os.path.exists(test_category_dir):
        os.makedirs(test_category_dir)

    # 获取当前类别的所有图片
    images = [image for image in os.listdir(os.path.join(data_dir, category))]
    image_paths = [os.path.join(data_dir, category, image) for image in images]  # 完整的文件路径

    # 划分数据，先划分出训练集和非训练集（即验证集和测试集）
    train_images, non_train_images = train_test_split(image_paths, test_size=0.3, random_state=42)
    # 非训练集中，按照1:2的比例划分出验证集和测试集
    val_images, test_images = train_test_split(non_train_images, test_size=2/3, random_state=42)

    # 复制图片到对应的子类文件夹内
    for image in train_images:
        shutil.copy(image, os.path.join(train_category_dir, os.path.basename(image)))
    for image in val_images:
        shutil.copy(image, os.path.join(val_category_dir, os.path.basename(image)))
    for image in test_images:
        shutil.copy(image, os.path.join(test_category_dir, os.path.basename(image)))

print('数据集划分完成。')