# import numpy as np
# import torch
# from torchvision import transforms
# from PIL import Image
# import matplotlib.pyplot as plt
# from train import GraphClassification  # 确保正确导入您的模型
# import os
# os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
# # 设置设备
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# import torch.nn.functional as F
#
# # os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
# # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#
# # 加载模型
# model_path = './artwork_zmh-OilPainting4/ResNet152-best.pth'
# model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
# model.load_state_dict(torch.load(model_path))
# model.eval()
#
# # 图像预处理
# def preprocess_image(image_path):
#     transform = transforms.Compose([
#         transforms.Resize((256, 256)),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
#     ])
#     image = Image.open(image_path)
#     image_tensor = transform(image).unsqueeze(0).to(device)
#     return image, image_tensor
#
# def visualize_core_nodes(image_path, model):
#     original_image, image_tensor = preprocess_image(image_path)
#     original_size = original_image.size
#
#     with torch.no_grad():
#         nodes_output = model(image_tensor, return_nodes=True)
#     nodes_output = nodes_output.squeeze(0)
#
#     nodes_output_upsampled = F.interpolate(nodes_output.unsqueeze(0), size=original_size, mode='bilinear', align_corners=True)
#     nodes_output_upsampled = nodes_output_upsampled.squeeze(0)
#
#     _, indices = torch.max(nodes_output_upsampled, dim=0)
#     indices = indices.cpu().numpy()
#
#     fig, axs = plt.subplots(1, 2, figsize=(12, 6))
#
#     axs[0].imshow(original_image)
#     axs[0].set_title('Original Image')
#     axs[0].axis('off')
#
#     axs[1].imshow(original_image)
#     overlay = indices.astype(np.float32)
#     im = axs[1].imshow(overlay, alpha=0.5, cmap='jet', extent=[0, original_size[0], original_size[1], 0])
#     axs[1].set_title('Feature Blocks with Coordinates')
#     axs[1].axis('off')
#
#     # 添加图注：为每个特征块创建一个代表性的点和颜色
#     colors = [im.cmap(im.norm(value)) for value in range(20)]
#     patches = [plt.Line2D([0], [0], marker='o', color='w', label=f'Block {i}',
#                           markerfacecolor=c, markersize=10) for i, c in enumerate(colors)]
#     plt.legend(handles=patches, bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0.)
#
#     # 打印每个特征块的坐标信息
#     block_coordinates = {}
#     for i in range(10):
#         mask = indices == i
#         y, x = np.where(mask)
#         if len(x) > 0 and len(y) > 0:
#             centroid_x, centroid_y = np.mean(x), np.mean(y)
#             if 0 <= centroid_x < original_size[0] and 0 <= centroid_y < original_size[1]:
#                 axs[1].text(centroid_x, centroid_y, f"{i}", color='black', ha='center', va='center')
#                 block_coordinates[i] = (centroid_x, centroid_y)
#
#     plt.show()
#
#     # 打印坐标信息
#     for block, coords in block_coordinates.items():
#         print(f"Block {block}: Coordinates (x, y) = ({coords[0]:.2f}, {coords[1]:.2f})")
#
#
#
# # 测试图像路径
# image_path = 'data/artwork_zmh-OilPainting4/test/10/B(222)_01_long.jpg'
# visualize_core_nodes(image_path, model)
#
#



import numpy as np
import torch
from torchvision import transforms
from PIL import Image
import matplotlib.pyplot as plt
from train import GraphClassification  # 确保正确导入您的模型
import os
import torch.nn.functional as F

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 加载模型
model_path = './artwork_zmh-OilPainting4/ResNet152-best.pth'
model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
model.load_state_dict(torch.load(model_path))
model.eval()

# 图像预处理
def preprocess_image(image_path):
    transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    image = Image.open(image_path).convert('RGB')
    image_tensor = transform(image).unsqueeze(0).to(device)
    return image, image_tensor

def visualize_core_nodes(image_path, model):
    original_image, image_tensor = preprocess_image(image_path)
    original_size = original_image.size

    with torch.no_grad():
        nodes_output = model(image_tensor, return_nodes=True)
    nodes_output = nodes_output.squeeze(0)

    nodes_output_upsampled = F.interpolate(nodes_output.unsqueeze(0), size=original_size, mode='bilinear', align_corners=True)
    nodes_output_upsampled = nodes_output_upsampled.squeeze(0)

    _, indices = torch.max(nodes_output_upsampled, dim=0)
    indices = indices.cpu().numpy()

    fig, axs = plt.subplots(1, 2, figsize=(12, 6))

    axs[0].imshow(original_image)
    axs[0].set_title('Original Image')
    axs[0].axis('off')

    axs[1].imshow(original_image)
    overlay = indices.astype(np.float32)
    im = axs[1].imshow(overlay, alpha=0.5, cmap='jet', extent=[0, original_size[0], original_size[1], 0])
    axs[1].set_title('Feature Blocks with Coordinates')
    axs[1].axis('off')

    # 添加图注：为每个特征块创建一个代表性的点和颜色
    colors = [im.cmap(im.norm(value)) for value in range(10)]
    patches = [plt.Line2D([0], [0], marker='o', color='w', label=f'Block {i}',
                          markerfacecolor=c, markersize=10) for i, c in enumerate(colors)]
    plt.legend(handles=patches, bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0.)

    # 打印每个特征块的坐标信息
    block_coordinates = {}
    for i in range(1,10):
        mask = indices == i
        y, x = np.where(mask)
        if len(x) > 0 and len(y) > 0:
            centroid_x, centroid_y = np.mean(x), np.mean(y)
            if 0 <= centroid_x < original_size[0] and 0 <= centroid_y < original_size[1]:
                axs[1].text(centroid_x, centroid_y, f"{i}", color='black', ha='center', va='center')
                block_coordinates[i] = (centroid_x, centroid_y)

    plt.show()

    # 打印坐标信息
    for block, coords in block_coordinates.items():
        print(f"Block {block}: Coordinates (x, y) = ({coords[0]:.2f}, {coords[1]:.2f})")

# 遍历文件夹中的所有图像
folder_path = "data/artwork_zmh-OilPainting4/test/10/"

for img_file in os.listdir(folder_path):
    if img_file.endswith(('.jpg', '.jpeg', '.png')):
        img_path = os.path.join(folder_path, img_file)
        print(f"Processing {img_path}")
        visualize_core_nodes(img_path, model)

#
#
# import numpy as np
# import torch
# from torchvision import transforms
# from PIL import Image
# import matplotlib.pyplot as plt
# from train import GraphClassification  # 确保正确导入您的模型
# import os
# import torch.nn.functional as F
#
# os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#
# # 加载模型
# model_path = './artwork_zmh-OilPainting4/ResNet152-best.pth'
# model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
# model.load_state_dict(torch.load(model_path))
# model.eval()
#
# # 图像预处理
# def preprocess_image(image_path):
#     transform = transforms.Compose([
#         transforms.Resize((256, 256)),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
#     ])
#     image = Image.open(image_path).convert('RGB')
#     image_tensor = transform(image).unsqueeze(0).to(device)
#     return image, image_tensor
#
# def visualize_core_nodes(image_path, model):
#     original_image, image_tensor = preprocess_image(image_path)
#     original_size = original_image.size
#
#     with torch.no_grad():
#         nodes_output = model(image_tensor, return_nodes=True)
#     nodes_output = nodes_output.squeeze(0)
#
#     nodes_output_upsampled = F.interpolate(nodes_output.unsqueeze(0), size=original_size, mode='bilinear', align_corners=True)
#     nodes_output_upsampled = nodes_output_upsampled.squeeze(0)
#
#     _, indices = torch.max(nodes_output_upsampled, dim=0)
#     indices = indices.cpu().numpy()
#
#     fig, axs = plt.subplots(1, 2, figsize=(12, 6))
#
#     axs[0].imshow(original_image)
#     axs[0].set_title('Original Image')
#     axs[0].axis('off')
#
#     axs[1].imshow(original_image)
#     overlay = indices.astype(np.float32)
#     im = axs[1].imshow(overlay, alpha=0.5, cmap='jet', extent=[0, original_size[0], original_size[1], 0])
#     axs[1].set_title('Feature Blocks with Coordinates')
#     axs[1].axis('off')
#
#     # 打印每个特征块的坐标信息
#     block_coordinates = {}
#     for i in range(nodes_output.size(0)):  # 遍历所有特征块
#         mask = indices == i
#         y, x = np.where(mask)
#         if len(x) > 0 and len(y) > 0:
#             centroid_x, centroid_y = np.mean(x), np.mean(y)
#             if 0 <= centroid_x < original_size[0] and 0 <= centroid_y < original_size[1]:
#                 axs[1].text(centroid_x, centroid_y, f"{i}", color='black', ha='center', va='center')
#                 block_coordinates[i] = (centroid_x, centroid_y)
#
#     plt.show()
#
#     # 打印坐标信息
#     for block, coords in block_coordinates.items():
#         print(f"Block {block}: Coordinates (x, y) = ({coords[0]:.2f}, {coords[1]:.2f})")
#
# # 遍历文件夹中的所有图像
# folder_path = "data/artwork_zmh-OilPainting4/test/10/"
#
# for img_file in os.listdir(folder_path):
#     if img_file.endswith(('.jpg', '.jpeg', '.png')):
#         img_path = os.path.join(folder_path, img_file)
#         print(f"Processing {img_path}")
#         visualize_core_nodes(img_path, model)
