import numpy as np
import torch
from torchvision import transforms
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
from train import GraphClassification
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# 加载模型
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
model.load_state_dict(torch.load('./ceramic visual pattern/ResNet101-best.pth'))
model.eval()

# 图像预处理
def preprocess_image(img_path):
    transform = transforms.Compose([
        transforms.Resize((128, 128)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.3980, 0.4097, 0.3696], std=[0.1468, 0.1340, 0.1303]),
    ])
    img = Image.open(img_path)
    img_tensor = transform(img).unsqueeze(0).to(device)
    return img, img_tensor

# 可视化节点区域
def visualize_nodes(img, nodes):
    # 对节点特征进行平均以生成热图
    heat_map = nodes.mean(dim=0)  # 在特征维上求平均
    heat_map = heat_map.detach().cpu().numpy()  # 转换为NumPy数组

    # 绘制原始图像
    plt.imshow(img)
    # 绘制热图
    plt.imshow(heat_map, alpha=0.45, cmap='hot')  # alpha控制透明度
    plt.axis('on')
    plt.show()

# 测试图像
img_path = 'data/ceramic visual pattern/test/10/736_01_long.jpg'
img, img_tensor = preprocess_image(img_path)

nodes = model(img_tensor, return_nodes=True)
visualize_nodes(img, nodes)


