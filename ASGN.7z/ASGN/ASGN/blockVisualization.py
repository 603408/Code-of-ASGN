# # import numpy as np
# # import torch
# # from torchvision import transforms
# # from PIL import Image
# # import matplotlib.pyplot as plt
# # from train import GraphClassification  # 确保正确导入您的模型
# # import os
# # import torch.nn.functional as F
# #
# # os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
# # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# #
# # # 加载模型
# # model_path = './artwork_zmh-OilPainting4/ResNet152-best.pth'
# # model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
# # model.load_state_dict(torch.load(model_path))
# # model.eval()
# #
# # # 图像预处理
# # def preprocess_image(image_path):
# #     transform = transforms.Compose([
# #         transforms.Resize((256, 256)),
# #         transforms.ToTensor(),
# #         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
# #     ])
# #     image = Image.open(image_path).convert('RGB')
# #     image_tensor = transform(image).unsqueeze(0).to(device)
# #     return image, image_tensor
# #
# # def visualize_core_nodes(image_path, model):
# #     original_image, image_tensor = preprocess_image(image_path)
# #     original_size = original_image.size
# #
# #     with torch.no_grad():
# #         nodes_output = model(image_tensor, return_nodes=True)
# #     nodes_output = nodes_output.squeeze(0)
# #
# #     # 遍历每个block
# #     fig, axs = plt.subplots(nodes_output.size(0), 2, figsize=(12, 6 * nodes_output.size(0)))
# #
# #     for i in range(nodes_output.size(0)):
# #         block_output = nodes_output[i]
# #
# #         # 将每个block的特征图上采样到原始图像的尺寸
# #         block_output_upsampled = F.interpolate(block_output.unsqueeze(0).unsqueeze(0), size=original_size, mode='nearest')
# #         block_output_upsampled = block_output_upsampled.squeeze(0).squeeze(0)
# #
# #         indices = block_output_upsampled.cpu().numpy()
# #
# #         # 绘制原始图像和特征块热力图
# #         axs[i, 0].imshow(original_image)
# #         axs[i, 0].set_title('Original Image')
# #         axs[i, 0].axis('off')
# #
# #         axs[i, 1].imshow(original_image)
# #         overlay = indices.astype(np.float32)
# #         im = axs[i, 1].imshow(overlay, alpha=0.5, cmap='jet', extent=[0, original_size[0], original_size[1], 0])
# #         axs[i, 1].set_title(f'Feature Blocks - Layer {i}')
# #         axs[i, 1].axis('off')
# #
# #     plt.show()
# #
# # # 遍历文件夹中的所有图像
# # folder_path = "data/artwork_zmh-OilPainting4/test/10/"
# #
# # for img_file in os.listdir(folder_path):
# #     if img_file.endswith(('.jpg', '.jpeg', '.png')):
# #         img_path = os.path.join(folder_path, img_file)
# #         print(f"Processing {img_path}")
# #         visualize_core_nodes(img_path, model)
#
#
#
# import numpy as np
# import torch
# from torchvision import transforms
# from PIL import Image
# import matplotlib.pyplot as plt
# from train import GraphClassification  # 确保正确导入您的模型
# import os
# import torch.nn.functional as F
#
# os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#
# # 加载模型
# model_path = './artwork_zmh-OilPainting4/ResNet152-best.pth'
# model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
# model.load_state_dict(torch.load(model_path))
# model.eval()
#
# # 图像预处理
# def preprocess_image(image_path):
#     transform = transforms.Compose([
#         transforms.Resize((256, 256)),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
#     ])
#     image = Image.open(image_path).convert('RGB')
#     image_tensor = transform(image).unsqueeze(0).to(device)
#     return image, image_tensor
#
# def visualize_core_nodes(image_path, model):
#     original_image, image_tensor = preprocess_image(image_path)
#     original_size = original_image.size
#
#     with torch.no_grad():
#         nodes_output = model(image_tensor, return_nodes=True)
#     nodes_output = nodes_output.squeeze(0)
#
#     # 遍历每个block
#     num_blocks = nodes_output.size(0)
#     fig, axs = plt.subplots(num_blocks, 2, figsize=(12, 6 * num_blocks))
#
#     for i in range(num_blocks):
#         block_output = nodes_output[i]
#
#         # 将每个block的特征图上采样到原始图像的尺寸
#         block_output_upsampled = F.interpolate(block_output.unsqueeze(0).unsqueeze(0), size=original_size, mode='bilinear', align_corners=True)
#         block_output_upsampled = block_output_upsampled.squeeze(0).squeeze(0)
#
#         indices = block_output_upsampled.cpu().numpy()
#
#         # 绘制原始图像和特征块热力图
#         axs[i, 0].imshow(original_image)
#         axs[i, 0].set_title('Original Image')
#         axs[i, 0].axis('off')
#
#         axs[i, 1].imshow(original_image)
#         overlay = indices.astype(np.float32)
#         im = axs[i, 1].imshow(overlay, alpha=0.5, cmap='jet', extent=[0, original_size[0], original_size[1], 0])
#         axs[i, 1].set_title(f'Feature Blocks - Layer {i}')
#         axs[i, 1].axis('off')
#
#     plt.tight_layout()
#     plt.show()
#
# # 遍历文件夹中的所有图像
# folder_path = "data/artwork_zmh-OilPainting4/test/18/"
#
# for img_file in os.listdir(folder_path):
#     if img_file.endswith(('.jpg', '.jpeg', '.png')):
#         img_path = os.path.join(folder_path, img_file)
#         print(f"Processing {img_path}")
#         visualize_core_nodes(img_path, model)


import numpy as np
import torch
from torchvision import transforms
from PIL import Image
import matplotlib.pyplot as plt
from train import GraphClassification  # 确保正确导入您的模型
import os
import torch.nn.functional as F

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 加载模型
model_path = './artwork_zmh-OilPainting4/ResNet152-best.pth'
model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
model.load_state_dict(torch.load(model_path))
model.eval()

# 图像预处理
def preprocess_image(image_path):
    transform = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    image = Image.open(image_path).convert('RGB')
    image_tensor = transform(image).unsqueeze(0).to(device)
    return image, image_tensor

def visualize_core_nodes(image_path, model):
    original_image, image_tensor = preprocess_image(image_path)
    original_size = original_image.size

    with torch.no_grad():
        nodes_output = model(image_tensor, return_nodes=True)
    nodes_output = nodes_output.squeeze(0)

    # 遍历每个block
    num_blocks = nodes_output.size(0)
    fig, axs = plt.subplots(num_blocks, 2, figsize=(12, 6 * num_blocks))

    for i in range(num_blocks):
        block_output = nodes_output[i]

        # 将每个block的特征图上采样到原始图像的尺寸
        block_output_upsampled = F.interpolate(block_output.unsqueeze(0).unsqueeze(0), size=original_size, mode='bilinear', align_corners=True)
        block_output_upsampled = block_output_upsampled.squeeze(0).squeeze(0)

        # 增强对比度
        block_output_upsampled = (block_output_upsampled - block_output_upsampled.min()) / (block_output_upsampled.max() - block_output_upsampled.min())

        indices = block_output_upsampled.cpu().numpy()

        # 绘制原始图像和特征块热力图
        axs[i, 0].imshow(original_image)
        axs[i, 0].set_title('Original Image')
        axs[i, 0].axis('off')

        axs[i, 1].imshow(original_image)
        overlay = indices.astype(np.float32)
        im = axs[i, 1].imshow(overlay, alpha=0.5, cmap='jet', extent=[0, original_size[0], original_size[1], 0])
        axs[i, 1].set_title(f'Feature Blocks - Layer {i}')
        axs[i, 1].axis('off')

    plt.tight_layout()
    plt.show()

# 遍历文件夹中的所有图像
folder_path = "data/artwork_zmh-OilPainting4/test/19/"

for img_file in os.listdir(folder_path):
    if img_file.endswith(('.jpg', '.jpeg', '.png')):
        img_path = os.path.join(folder_path, img_file)
        print(f"Processing {img_path}")
        visualize_core_nodes(img_path, model)
