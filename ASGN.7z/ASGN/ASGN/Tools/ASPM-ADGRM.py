# #############Block_Num必须和class数量一致
#
# from torch.nn.modules.module import Module
# from torch.nn.parameter import Parameter
# import torch.nn as nn
# import torch
# import torch.nn.functional as F
# import math
#
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '0'
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# class GraphAttentionLayer(nn.Module):
#     """
#     简单的图注意力层实现
#     """
#     def __init__(self, in_features, out_features, dropout=0.6, alpha=0.2):
#         super(GraphAttentionLayer, self).__init__()
#         self.in_features = in_features
#         self.out_features = out_features
#         self.dropout = dropout
#         self.alpha = alpha  # LeakyReLU的负斜率
#
#         # 定义可学习的权重
#         self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
#         nn.init.xavier_uniform_(self.W.data, gain=1.414)
#         self.a = nn.Parameter(torch.zeros(size=(2*out_features, 1)))
#         nn.init.xavier_uniform_(self.a.data, gain=1.414)
#
#         self.leakyrelu = nn.LeakyReLU(self.alpha)
#
#     def forward(self, h, adj):
#         """
#         h: 输入特征 (N, in_features)
#         adj: 邻接矩阵 (N, N)
#         """
#         Wh = torch.matmul(h, self.W)  # 节点特征变换 (N, out_features)
#         a_input = self._prepare_attentional_mechanism_input(Wh)  # 准备注意力机制的输入
#         e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(2))  # 注意力系数 (N, N)
#
#         zero_vec = -9e15*torch.ones_like(e)
#         attention = torch.where(adj > 0, e, zero_vec)  # 仅对邻接矩阵中的节点应用注意力系数
#         attention = F.softmax(attention, dim=1)  # 归一化注意力系数 (N, N)
#         attention = F.dropout(attention, self.dropout, training=self.training)
#
#         h_prime = torch.matmul(attention, Wh)  # 聚合邻居特征
#
#         return h_prime
#
#     def _prepare_attentional_mechanism_input(self, Wh):
#         N = Wh.size()[0]  # 节点数
#         Wh_repeated_in_chunks = Wh.repeat_interleave(N, dim=0)
#         Wh_repeated_alternating = Wh.repeat(N, 1)
#         all_combinations_matrix = torch.cat([Wh_repeated_in_chunks, Wh_repeated_alternating], dim=1)
#
#         return all_combinations_matrix.view(N, N, 2 * self.out_features)
#
#
#
# class Graph2dConvolution(Module):
#     """
#     Graph Convolution Layer enhanced with an Attention Mechanism
#     """
#     def __init__(
#         self,
#         in_channels,
#         out_channels,
#         kernel_size,
#         block_num,
#         stride=1,
#         padding=0,
#         dilation=1,
#         groups=1,
#         bias=False,
#         padding_mode='zeros',
#         adj_mask=None
#     ):
#         super(Graph2dConvolution, self).__init__()
#         self.Conv2d = nn.Conv2d(
#             in_channels,
#             out_channels,
#             kernel_size,
#             stride,
#             padding,
#             dilation,
#             groups,
#             bias,
#             padding_mode)
#         self.in_features = in_channels
#         self.out_features = out_channels
#         self.W = Parameter(torch.randn(in_channels, in_channels))
#         self.block_num = block_num
#         self.adj_mask = adj_mask
#         # print(in_channels)
#         # print(out_channels)
#         # print('1111111111111111111111111111111111111111111111111111111')
#         # Attention parameters
#         self.attention_weight = Parameter(torch.Tensor(out_channels, out_channels))
#         # self.attention_weight = Parameter(torch.Tensor(in_channels, in_channels))
#         # nn.init.xavier_uniform_(self.attention_weight, gain=1.414)
#         self.leakyrelu = nn.LeakyReLU(0.2)
#
#         self.reset_parameters()
#
#         self.attention_in = nn.Conv1d(in_channels=block_num, out_channels=in_channels, kernel_size=1)
#
#     def reset_parameters(self):
#         stdv = 1. / math.sqrt(self.W.size(1))
#         self.W.data.uniform_(-stdv, stdv)
#         nn.init.xavier_uniform_(self.attention_weight, gain=1.414)
#
#     def forward(self, input, index):
#         index = nn.functional.interpolate(index.float(), size=(input.shape[2], input.shape[3]), mode='nearest').long()
#         batch_size = input.shape[0]
#
#         # print(self.block_num)
#         index_ex = torch.zeros(batch_size, self.block_num, input.shape[2], input.shape[3], device=input.device)
#         index_ex = index_ex.scatter_(1, index, 1)
#
#         block_value_sum = torch.sum(index_ex, dim=(2, 3))
#
#         input_ = input.repeat(self.block_num, 1, 1, 1, 1).permute(1, 0, 2, 3, 4)
#         index_ex = index_ex.unsqueeze(2)
#         input_means = torch.sum(index_ex * input_, dim=(3, 4)) / (block_value_sum + (block_value_sum == 0).float()).unsqueeze(2)
#         # print(input_means.shape)
#         # Compute attention coefficients
#         # a_input = torch.cat([input_means, input_means], dim=1)
#
#         a_input = input_means.permute(0, 2, 1)
#         print(a_input.shape)
#         print(self.attention_weight.shape)
#         e = self.leakyrelu(torch.matmul(a_input, self.attention_weight))
#         # e = self.leakyrelu(torch.matmul(input_means, self.attention_weight))
#
#         #attention = F.softmax(e, dim=1)
#         attention = F.softmax(e, dim=-1)
#
#
#         # Apply attention on the adj matrix
#         adj = torch.matmul(input_means, self.W)
#         adj = adj * attention.permute(0, 2, 1)
#
#         if self.adj_mask is not None:
#             adj = adj * self.adj_mask.unsqueeze(0)
#
#         adj_means = torch.matmul(adj, input_means.permute(0, 2, 1))
#         adj_means = self.attention_in(adj_means).permute(0, 2, 1)
#
#         features = torch.sum(index_ex * (input_ + adj_means.unsqueeze(3).unsqueeze(4)), dim=1)
#         features = self.Conv2d(features)
#         return features
#
#     def __repr__(self):
#         return '{} ({} -> {})'.format(self.__class__.__name__, self.in_features, self.out_features)






#######################################################################################################################
#######################################################################################################################
##可以随机设置Block_Num
#######################################################################################################################
#######################################################################################################################

from torch.nn.modules.module import Module
from torch.nn.parameter import Parameter
import torch.nn as nn
import torch
import torch.nn.functional as F
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
class GraphAttentionLayer(nn.Module):

    """
    简单的图注意力层实现
    """
    def __init__(self, in_features, out_features, dropout=0.6, alpha=0.2):
        super(GraphAttentionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.alpha = alpha  # LeakyReLU的负斜率

        # 定义可学习的权重
        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.zeros(size=(2*out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, h, adj):
        """
        h: 输入特征 (N, in_features)
        adj: 邻接矩阵 (N, N)
        """
        Wh = torch.matmul(h, self.W)  # 节点特征变换 (N, out_features)
        a_input = self._prepare_attentional_mechanism_input(Wh)  # 准备注意力机制的输入
        e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(2))  # 注意力系数 (N, N)

        zero_vec = -9e15*torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)  # 仅对邻接矩阵中的节点应用注意力系数
        attention = F.softmax(attention, dim=1)  # 归一化注意力系数 (N, N)
        attention = F.dropout(attention, self.dropout, training=self.training)

        h_prime = torch.matmul(attention, Wh)  # 聚合邻居特征

        return h_prime

    def _prepare_attentional_mechanism_input(self, Wh):
        N = Wh.size()[0]  # 节点数
        Wh_repeated_in_chunks = Wh.repeat_interleave(N, dim=0)
        Wh_repeated_alternating = Wh.repeat(N, 1)
        all_combinations_matrix = torch.cat([Wh_repeated_in_chunks, Wh_repeated_alternating], dim=1)

        return all_combinations_matrix.view(N, N, 2 * self.out_features)



class Graph2dConvolution(Module):
    """
    Graph Convolution Layer enhanced with an Attention Mechanism
    """
    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        block_num,
        stride=1,
        padding=0,
        dilation=1,
        groups=1,
        bias=False,
        padding_mode='zeros',
        adj_mask=None
    ):
        super(Graph2dConvolution, self).__init__()
        self.Conv2d = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            dilation,
            groups,
            bias,
            padding_mode)
        self.in_features = in_channels
        self.out_features = out_channels
        self.W = Parameter(torch.randn(in_channels, in_channels))
        self.block_num = block_num
        self.adj_mask = adj_mask
        # print(in_channels)
        # print(out_channels)
        # print('1111111111111111111111111111111111111111111111111111111')
        # Attention parameters
        self.attention_weight = Parameter(torch.Tensor(block_num, out_channels))
        # self.attention_weight = Parameter(torch.Tensor(in_channels, in_channels))
        # nn.init.xavier_uniform_(self.attention_weight, gain=1.414)
        self.leakyrelu = nn.LeakyReLU(0.2)

        self.reset_parameters()

        self.attention_in = nn.Conv1d(in_channels=block_num, out_channels=in_channels, kernel_size=1)

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.W.size(1))
        self.W.data.uniform_(-stdv, stdv)
        nn.init.xavier_uniform_(self.attention_weight, gain=1.414)

    def forward(self, input, index):
        index = nn.functional.interpolate(index.float(), size=(input.shape[2], input.shape[3]), mode='nearest').long()
        batch_size = input.shape[0]

        # print(self.block_num)
        index_ex = torch.zeros(batch_size, self.block_num, input.shape[2], input.shape[3], device=input.device)
        index_ex = index_ex.scatter_(1, index, 1)

        block_value_sum = torch.sum(index_ex, dim=(2, 3))

        input_ = input.repeat(self.block_num, 1, 1, 1, 1).permute(1, 0, 2, 3, 4)
        index_ex = index_ex.unsqueeze(2)
        input_means = torch.sum(index_ex * input_, dim=(3, 4)) / (block_value_sum + (block_value_sum == 0).float()).unsqueeze(2)
        # print(input_means.shape)
        # Compute attention coefficients
        # a_input = torch.cat([input_means, input_means], dim=1)

        a_input = input_means.permute(0, 2, 1)
        # print(a_input.shape)
        # print(self.attention_weight.shape)
        e = self.leakyrelu(torch.matmul(a_input, self.attention_weight))
        # e = self.leakyrelu(torch.matmul(input_means, self.attention_weight))

        #attention = F.softmax(e, dim=1)
        attention = F.softmax(e, dim=-1)


        # Apply attention on the adj matrix
        adj = torch.matmul(input_means, self.W)
        # print(adj.shape)
        # print(attention.permute(0, 2, 1).shape)



        # attention.permute(0, 2, 1)的形状是[64, 22, 128]
        # 将attention.permute(0, 2, 1)转换为[64, 128, 22]以匹配池化操作的期望输入
        attentionnn = attention.permute(0, 2, 1).permute(0, 2, 1)

        # 使用适配性平均池化
        pool = nn.AdaptiveAvgPool1d(self.block_num)
        b_pooled = pool(attentionnn)
        # 将b_pooled转换回期望的形状[64, 10, 128]
        final = b_pooled.permute(0, 2, 1)

        adj = adj * final



        if self.adj_mask is not None:
            adj = adj * self.adj_mask.unsqueeze(0)

        adj_means = torch.matmul(adj, input_means.permute(0, 2, 1))
        adj_means = self.attention_in(adj_means).permute(0, 2, 1)

        features = torch.sum(index_ex * (input_ + adj_means.unsqueeze(3).unsqueeze(4)), dim=1)
        features = self.Conv2d(features)
        return features

    def __repr__(self):
        return '{} ({} -> {})'.format(self.__class__.__name__, self.in_features, self.out_features)
