import torch.nn as nn
import math
import torch.utils.model_zoo as model_zoo  #导入了 PyTorch 的模型下载工具，允许从预定义的URL下载预训练模型。
import torch
import torch.nn.backends  #导入了 PyTorch 的神经网络后端，可能是指定后端类型的设置
import torch.nn.functional as F  #导入了 PyTorch 的函数式接口模块，其中 F 是用于定义神经网络层的函数集合
from torch.nn.parameter import Parameter   #从 PyTorch 的参数模块中导入参数，用于定义可学习的模型参数
from torch.nn import init   #从 PyTorch 的初始化模块中导入初始化函数，用于对模型参数进行初始化操作
from math import pi   #从 Python 的数学库中导入 pi 常数，即圆周率
import math   #导入 Python 的数学库，可能是为了在后续代码中使用数学函数
import numpy as np  #导入了 NumPy 库，用于在 Python 中进行数值计算和数组操作
import matplotlib.pyplot as plt  #导入了 matplotlib 库的 pyplot 模块，用于绘制图表和可视化数据

model_urls = {
    'resnet18': 'https://download.pytorch.org/models/resnet18-5c106cde.pth',
    'resnet34': 'https://download.pytorch.org/models/resnet34-333f7ec4.pth',
    'resnet50': 'https://download.pytorch.org/models/resnet50-19c8e357.pth',
    'resnet101': 'https://download.pytorch.org/models/resnet101-5d3b4d8f.pth',
    'resnet152': 'https://download.pytorch.org/models/resnet152-b121ed2d.pth',
} #定义了一组预训练模型的下载链接

def conv3x3(in_planes, out_planes, stride=1):  # in_planes（输入通道数）、out_planes（输出通道数）和可选参数 stride（步长，默认值为1）
    "3x3 convolution with padding"  #执行带有填充的3x3卷积操作
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,   #创建了一个 nn.Conv2d 对象，并将其返回  nn.Conv2d 是 PyTorch 中用于定义二维卷积层的类
                     padding=1, bias=False)   #在这里，我们传入了参数 in_planes、out_planes 和 stride，卷积核大小为3x3（kernel_size=3）、填充大小为1（padding=1）,不使用偏置项（bias=False）



class BasicBlock(nn.Module):  #用于构建 ResNet 中的基本残差块
    expansion = 1   # expansion，表示该基本块的扩展因子。在 ResNet 中，基本块的输出通道数相对于输入通道数的倍数。对于基本块，扩展因子为1，即输出通道数等于输入通道数

    def __init__(self, inplanes, planes, stride=1, downsample=None):   #inplanes（输入通道数）、planes（输出通道数）、可选参数 stride（步长，默认值为1）和可选参数 downsample（下采样，默认为None）
        # 调用了父类 nn.Module 的初始化方法，确保正确地初始化了 BasicBlock 类的实例
        super(BasicBlock, self).__init__()
        # 创建了一个 3x3 的卷积层 conv1。conv3x3 是一个在前面定义的函数，用于创建一个带有3x3卷积核的卷积层，它接受输入通道数 inplanes、输出通道数 planes 和步长 stride 作为参数
        self.conv1 = conv3x3(inplanes, planes, stride)
        #创建了一个批归一化层 bn1，用于对 conv1 的输出进行批归一化。planes 参数指定了 bn1 的输入通道数
        self.bn1 = nn.BatchNorm2d(planes)
        # 创建了一个激活函数层 relu，用于对 bn1 的输出进行激活操作。inplace=True 表示在原地执行操作，节省内存。
        self.relu = nn.ReLU(inplace=True)
        # 创建了另一个 3x3 的卷积层 conv2，用于对 relu 的输出进行卷积操作。输入和输出通道数都是 planes，即与 conv1 相同
        self.conv2 = conv3x3(planes, planes)
        # 创建了另一个批归一化层 bn2，用于对 conv2 的输出进行批归一化
        self.bn2 = nn.BatchNorm2d(planes)
        # 创建了另一个批归一化层 bn2，用于对 conv2 的输出进行批归一化
        self.downsample = downsample
        # 将传入的 stride 参数赋值给类的属性 stride，表示残差块的步长
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out




class Bottleneck(nn.Module):
    expansion = 4   # 指定残差块的扩展因子，即输出通道数相对于输入通道数的倍数。在瓶颈结构中，最后一个卷积层输出的通道数是前两个卷积层的 4 倍

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)   #创建了一个1x1的卷积层 conv1，用于降低输入的通道数，从 inplanes 到 planes
        self.bn1 = nn.BatchNorm2d(planes)  #创建了一个批归一化层 bn1，用于对 conv1 的输出进行批归一化
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)  #创建了一个3x3的卷积层 conv2，用于对特征图进行卷积操作
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):   #定义了前向传播方法 forward，用于计算残差块的前向传播结果
        residual = x   #将输入 x 赋值给 residual，作为残差连接的输入

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)  #对批归一化后的结果进行ReLU激活

        out = self.conv2(out)
        out = self.bn2(out)  #对 conv2 的输出进行批归一化
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class ResNet(nn.Module):

    def __init__(self, block, layers, num_classes=1000):
        self.inplanes = 64
        super(ResNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)
        self.avgpool = nn.AvgPool2d(7)
        self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))

        return nn.Sequential(*layers)

    def forward(self, x):
        f = []
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        x = self.layer1(x)
        f.append(x)
        x = self.layer2(x)
        f.append(x)
        x = self.layer3(x)
        f.append(x)
        x = self.layer4(x)
        f.append(x)
        # x = self.avgpool(x)
        # x = x.view(x.size(0), -1)
        # x = self.fc(x)
        '''
        f中的每个元素的size分别是 bs 256 w/4 h/4， bs 512 w/8 h/8， 
        bs 1024 w/16 h/16， bs 2048 w/32 h/32
        '''
        return f

def resnet9(pretrained=False, progress=True, **kwargs):
    """Constructs a ResNet-18 model.

    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
    """
    model = ResNet(BasicBlock, [1, 1, 1, 1], **kwargs)
    return model


def resnet18(pretrained=False, progress=True, **kwargs):
    """Constructs a ResNet-18 model.

    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
    """
    model = ResNet(BasicBlock, [2, 2, 2, 2], **kwargs)
    if pretrained:
        
        #model.load_state_dict(torch.load("./resnet50-19c8e357.pth"))
        model.load_state_dict(model_zoo.load_url(model_urls['resnet18']))
    return model

def resnet34(pretrained=False, progress=True, **kwargs):
    """Constructs a ResNet-18 model.

    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
    """
    model = ResNet(BasicBlock, [3, 4, 6, 3], **kwargs)
    if pretrained:
        
        #model.load_state_dict(torch.load("./resnet50-19c8e357.pth"))
        model.load_state_dict(model_zoo.load_url(model_urls['resnet34']))
    return model

def resnet50(pretrained=True, **kwargs):
    """Constructs a ResNet-50 model.

    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
    """
    model = ResNet(Bottleneck, [3, 4, 6, 3], **kwargs)
    if pretrained:
        
        #model.load_state_dict(torch.load("./resnet50-19c8e357.pth"))
        model.load_state_dict(model_zoo.load_url(model_urls['resnet50']))
    return model

def resnet101(pretrained=False, progress=True, **kwargs):
    
    model = ResNet(Bottleneck, [3, 4, 23, 3], **kwargs)
    if pretrained:
        
        #model.load_state_dict(torch.load("./resnet50-19c8e357.pth"))
#         model.load_state_dict(torch.load("./unet/resnet101.pth"))
        model.load_state_dict(model_zoo.load_url(model_urls['resnet101']))
    return model

def resnet152(pretrained=False, progress=True, **kwargs):
    
    model = ResNet(Bottleneck, [3, 8, 36, 3], **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['resnet152']))
    return model


class dfpn(nn.Module):
    def __init__(self, backbone_pretrained=True, trans_channel_num=128, resnet_type='resnet50',resnet_layer=[256, 512, 1024, 2048]):
        ##ResNet 18&34    resnet_layer=[64, 128, 256, 512]
        ##ResNet 50    resnet_layer=[256, 512, 1024, 2048]
        ##ResNet 101    resnet_layer=[256, 512, 1024, 2048]
        ##ResNet 152    resnet_layer=[256, 512, 1024, 2048]
        super(dfpn, self).__init__()
        if resnet_type == 'resnet9':
            self.resnet = resnet9(backbone_pretrained)
        if resnet_type == 'resnet18':
            self.resnet = resnet18(backbone_pretrained)
        if resnet_type == 'resnet34':
            self.resnet = resnet34(backbone_pretrained)
        if resnet_type == 'resnet50':
            self.resnet = resnet50(backbone_pretrained)
        if resnet_type == 'resnet101':
            self.resnet = resnet101(backbone_pretrained)
        if resnet_type == 'resnet152':
            self.resnet = resnet152(backbone_pretrained)

        conv1_inchannel_num = trans_channel_num * 2
        conv2_inchannel_num = trans_channel_num * 3
        conv3_inchannel_num = trans_channel_num * 4

        self.conv1 = nn.Conv2d(conv1_inchannel_num, trans_channel_num, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(trans_channel_num)

        self.conv2 = nn.Conv2d(conv2_inchannel_num, trans_channel_num, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(trans_channel_num)

        self.conv3 = nn.Conv2d(conv3_inchannel_num, trans_channel_num, 3, padding=1)
        self.bn3 = nn.BatchNorm2d(trans_channel_num)

        self.unpool = nn.UpsamplingBilinear2d(scale_factor=2)

        self.convl1 = nn.Conv2d(resnet_layer[0], trans_channel_num, 1)
        self.convl2 = nn.Conv2d(resnet_layer[1], trans_channel_num, 1)
        self.convl3 = nn.Conv2d(resnet_layer[2], trans_channel_num, 1)
        self.convl4 = nn.Conv2d(resnet_layer[3], trans_channel_num, 1)

    def forward(self, images):
        f = self.resnet(images)

        # for i, feat in enumerate(f):
        #     print(f"Feature {i} shape: {feat.shape}")

        c1 = self.convl1(f[0])
        c2 = self.convl2(f[1])
        c3 = self.convl3(f[2])
        c4 = self.convl4(f[3])

        p4 = self.unpool(c4)
        p3 = self.conv1(torch.cat((p4, c3), 1))
        p3 = self.unpool(p3)
        p4 = self.unpool(p4)

        p2 = self.conv2(torch.cat((p3, p4, c2), 1))
        p2 = self.unpool(p2)
        p3 = self.unpool(p3)
        p4 = self.unpool(p4)

        p1 = self.conv3(torch.cat((p2, p3, p4, c1), 1))

        return p1