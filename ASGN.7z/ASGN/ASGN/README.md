# SAGN

Paper Name: "SAGN: Semantic-Aware Graph Network for Remote Sensing Scene Classification"

Paper Link: https://ieeexplore.ieee.org/abstract/document/10025702

Note: The key code has been uploaded and others will be uploaded shortly.

![image](https://user-images.githubusercontent.com/74549002/211795815-99f5b3a2-eb22-40b8-95c3-6fbb681601bc.png)
