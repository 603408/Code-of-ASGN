#测试每一个类别的 APRF-Score以及总的APRF-score
import torch
import torchvision.transforms as transforms
from torchvision import datasets
from torch.utils.data import DataLoader
from train import GraphClassification  # Ensure you have the correct path to the train module

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
test_dir = 'data/artwork_zmh-OilPainting4/test'

model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
model.load_state_dict(torch.load('./artwork_zmh-OilPainting4/best0612.pth'))
model.eval()

pretrained_size = 256
pretrained_means = [0.3980, 0.4097, 0.3696]
pretrained_stds = [0.1468, 0.1340, 0.1303]
test_transforms = transforms.Compose([
    transforms.Resize(pretrained_size),
    transforms.CenterCrop(pretrained_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=pretrained_means, std=pretrained_stds)
])

test_data = datasets.ImageFolder(root=test_dir, transform=test_transforms)
test_loader = DataLoader(test_data, batch_size=64, shuffle=False)

# Initialize statistics for precision, recall, and F1 score
class_stats = {class_idx: {'total': 0, 'correct': 0, 'TP': 0, 'FP': 0, 'FN': 0} for class_idx in test_data.class_to_idx.values()}

with torch.no_grad():
    for images, labels in test_loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)
        for pred, target in zip(predicted, labels):
            class_idx = target.item()
            class_stats[class_idx]['total'] += 1
            if pred == target:
                class_stats[class_idx]['correct'] += 1
                class_stats[class_idx]['TP'] += 1
            else:
                class_stats[pred.item()]['FP'] += 1
                class_stats[class_idx]['FN'] += 1

# Calculate and print precision, recall, and F1 score
print("Metrics per class:")
for class_idx, stats in class_stats.items():
    precision = stats['TP'] / (stats['TP'] + stats['FP']) if stats['TP'] + stats['FP'] > 0 else 0
    recall = stats['TP'] / (stats['TP'] + stats['FN']) if stats['TP'] + stats['FN'] > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0
    accuracy = stats['correct'] / stats['total'] * 100 if stats['total'] > 0 else 0
    print(f"Class {class_idx}: Accuracy: {accuracy:.2f}%, Precision: {precision:.2f}, Recall: {recall:.2f}, F1 Score: {f1:.2f}")

# Overall metrics
total_TP = sum(stat['TP'] for stat in class_stats.values())
total_FP = sum(stat['FP'] for stat in class_stats.values())
total_FN = sum(stat['FN'] for stat in class_stats.values())
total_correct = sum(stat['correct'] for stat in class_stats.values())
total_samples = sum(stat['total'] for stat in class_stats.values())

overall_precision = total_TP / (total_TP+total_FP) if total_TP + total_FP > 0 else 0
overall_recall = total_TP / (total_TP + total_FN) if total_TP + total_FN > 0 else 0
overall_f1 = 2 * overall_precision * overall_recall / (overall_precision + overall_recall) if overall_precision + overall_recall > 0 else 0
overall_accuracy = 100 * total_correct / total_samples if total_samples > 0 else 0

print(f'Overall Metrics - Accuracy: {overall_accuracy:.2f}%, Precision: {overall_precision:.4f}, Recall: {overall_recall:.4f}, F1 Score: {overall_f1:.4f}')
