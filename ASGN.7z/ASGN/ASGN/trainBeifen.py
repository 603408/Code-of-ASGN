#!/usr/bin/env python
# coding: utf-8
from torch.utils.data import DataLoader
import torch
from tqdm import tqdm
import numpy as np
import torch.nn as nn
import torch.optim.lr_scheduler as lr_scheduler
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import shutil
import torch.nn.functional as F
import matplotlib.pyplot as plt

import os

os.environ['CUDA_VISIBLE_DEVICES'] = '0'


# In[2]:

#定义准确率计算函数
def OA(pre_classes, gt_classes):
    return torch.sum(torch.tensor(pre_classes) == torch.tensor(gt_classes)).float() / len(pre_classes)
#将列表转换为PyTorch张量，比较预测和真实类别，计算匹配的数量，然后转换为浮点数，除以总数量得到准确率


# In[3]:

#定义预训练模型期望的输入尺寸、均值和标准差
pretrained_size = 256
pretrained_means = [0.3980, 0.4097, 0.3696]
pretrained_stds = [0.1468, 0.1340, 0.1303]

#定义训练数据的预处理步骤
train_transforms = transforms.Compose([
    transforms.Resize(pretrained_size),
    transforms.RandomRotation(5),
    transforms.RandomHorizontalFlip(0.5),
    transforms.RandomCrop(pretrained_size, padding=10),
    transforms.ToTensor(),
    transforms.Normalize(mean=pretrained_means,
                         std=pretrained_stds)
])


#定义测试数据的预处理步骤
test_transforms = transforms.Compose([
    transforms.Resize(pretrained_size),
    transforms.CenterCrop(pretrained_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=pretrained_means,
                         std=pretrained_stds)
])

# In[15]:


Log_path = 'artwork_zmh-OilPainting2/'
num_class = 22
train_dir = 'data/artwork_zmh-OilPainting2/train'
test_dir = 'data/artwork_zmh-OilPainting2/valid'

# Log_path = 'ex_AID/'
# num_class = 30
# train_dir = '/home/amax/yyq/Graph_convolution_self/Datasets/AID/28/train/'
# test_dir = '/home/amax/yyq/Graph_convolution_self/Datasets/AID/28/test/'

if not os.path.exists(Log_path):
    os.mkdir(Log_path)

#加载数据
train_data = datasets.ImageFolder(root=train_dir,
                                  transform=train_transforms)

test_data = datasets.ImageFolder(root=test_dir,
                                 transform=test_transforms)

#创建训练和测试的数据加载器，设置批量大小、是否打乱数据等
batch_size = 24
tra_Dataloader = DataLoader(train_data, batch_size, shuffle=True,
                            num_workers=8, pin_memory=True)
tes_Dataloader = DataLoader(test_data, batch_size * 4, shuffle=False,
                            num_workers=8, pin_memory=True)

# ![image.png](attachment:0fff90fb-a1a4-40cb-953d-4c89a4b733a1.png)

# In[5]:

#从自定义模块导入模型组件
from Tools.FEM import dfpn
from Tools.ASPM-ADGRM import Graph2dConvolution


# In[6]:
resnet_type = 'resnet18'

class GCN(nn.Module):
    def __init__(self, nfeat, ofeat, block_num):
        super(GCN, self).__init__()
        self.convindex = nn.Conv2d(nfeat, block_num, 5, padding=2)
        self.gc = Graph2dConvolution(nfeat, ofeat, kernel_size=3, block_num=block_num, padding=1)
        self.bn = nn.BatchNorm2d(ofeat)

    def forward(self, x):
        index_f = self.convindex(x)
        value, index = torch.max(index_f, dim=1, keepdim=True)
        x = self.gc(x, index)
        x = self.bn(x)
        return x



class GraphClassification(nn.Module):
    def __init__(self, block_num, labelnum, channel_num):
        super(GraphClassification, self).__init__()
        self.dpfn = dfpn(trans_channel_num=channel_num, resnet_type=resnet_type)
        self.gcn = GCN(channel_num, labelnum, block_num=block_num)

    def forward(self, img):#这里关于论文全连接层输出的部分
        features = self.dpfn(img)
        features = self.gcn(features)  ## 这里进行了图卷积操作
        final_class = torch.mean(features, dim=(2, 3)) ## 在宽度和高度维度上取平均值
        return final_class

# class GraphClassification(nn.Module):
#         def __init__(self, block_num, labelnum, channel_num):
#             super(GraphClassification, self).__init__()
#             self.dpfn = dfpn(trans_channel_num=channel_num, resnet_type=resnet_type)
#             self.gcn = GCN(channel_num, labelnum, block_num=block_num)
#
#         def forward(self, img, return_feature_maps=False):
#             features = self.dpfn(img)  # 这里进行了特征提取
#             gcn_features = self.gcn(features)  # 这里进行了图卷积操作
#             final_class = torch.mean(gcn_features, dim=(2, 3))  # 在宽度和高度维度上取平均值
#
#             if return_feature_maps:
#                 # 返回分类结果和GCN处理后的特征图
#                 return final_class, gcn_features
#             return final_class


# class GraphClassificationWithFeatures(GraphClassification):
#     def forward(self, img):
#         features = self.dpfn(img)
#         gcn_output = self.gcn(features)
#         final_class = torch.mean(gcn_output, dim=(2, 3))
#         return final_class, features  # 返回最终分类结果和dfpn层的特征


from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay
from Tools.performance import performance


def plot_confusion_matrix(labels, pred_labels, classes): #  定义了一个名为plot_confusion_matrix的函数，它接收三个参数：labels（真实的标签），pred_labels（预测的标签），和classes（类别的名称列表）
    #  创建一个Matplotlib图形对象fig，设置图形的分辨率（DPI）为100和尺寸为10x10英寸
    fig = plt.figure(dpi=150,figsize = (10, 10));
    #  在fig中添加一个子图ax。参数(1, 1, 1)指示这个子图是单一的子图（即，图形中只有这一个子图）
    ax = fig.add_subplot(1, 1, 1);
    #  使用confusion_matrix函数计算真实标签和预测标签之间的混淆矩阵，结果存储在cm+++++++-中
    cm = confusion_matrix(labels, pred_labels);
    #  创建一个ConfusionMatrixDisplay对象，它将基于cm绘制混淆矩阵，并使用classes提供的标签名称作为类别标签
    cm = ConfusionMatrixDisplay(cm, display_labels = classes);
    #  调用plot方法绘制混淆矩阵。values_format = 'd'指定数字格式为整数（用于表示样本数量），cmap = 'Blues'指定使用蓝色调色板，ax = ax指定绘制子图的位置
    cm.plot(values_format = 'd', cmap = 'Blues', ax = ax)
    #  将x轴的刻度标签旋转90度，通常是为了防止标签重叠，使它们更容易阅读
    plt.xticks(rotation = 90)

# In[1]:
if __name__ == '__main__':
    # In[ ]:

    # In[7]:
    # 定义模型的某些参数，这里block可能是指图卷积网络的块数量，tras_ch是转换层的通道数
    EPOCHS = 150
    FOUND_LR = 4e-5

    block = 22
    tras_ch = 128


    # In[9]:
    # 初始化GraphClassification模型，并将其移动到GPU上
    model = GraphClassification(block, num_class, tras_ch).cuda()
    # 定义损失函数为交叉熵损失，常用于多分类问题
    lossf = nn.CrossEntropyLoss()
    #初始化优化器为Adam，设置先前定义的学习率
    opt = torch.optim.Adam(model.parameters(), lr=FOUND_LR)
    #计算每轮(epoch)训练中的步数，即数据批次数
    STEPS_PER_EPOCH = len(tra_Dataloader)
    # 计算总步数，这可能用于调整学习率
    TOTAL_STEPS = STEPS_PER_EPOCH * (EPOCHS // 5)
    #  初始化学习率调度器，根据步数减少学习率
    scheduler = lr_scheduler.StepLR(opt, step_size=TOTAL_STEPS, gamma=0.1)

    best_acc_test = 0
    for epoch in range(EPOCHS):
        '''train'''
        model.train()
        losses = []
        for i,(img,label) in enumerate(tqdm(tra_Dataloader)):
            opt.zero_grad()
            img,label = img.cuda(),label.cuda()
            pred_cls = model(img)

            loss_class = lossf(pred_cls,label)
            loss = loss_class
            loss.backward()
            opt.step()
            scheduler.step()

            losses.append(float(loss.detach()))
            if i % 20 == 0:
                print(np.mean(losses))

        '''test'''
        with torch.no_grad():
            model.eval()
            pre_classes = []
            gt_classes = []
            for i,(img,label) in enumerate(tqdm(tes_Dataloader)):
                img,label = img.cuda(),label.cuda()
                pre_class = model(img)

                pre_classes = pre_classes + list(np.array(torch.argmax(pre_class,dim=1).detach().cpu()))
                gt_classes = gt_classes + list(np.array(label.cpu()))

            mean_acc = OA(pre_classes, gt_classes)
            mean_acc = round(float(mean_acc),4)
            print('epoch:',epoch,'test_precison:',mean_acc,'best_test:',best_acc_test)
            f = open(Log_path+'log.txt','a')
            f.write('Epoch:'+str(epoch)+'   acc:'+str(mean_acc)+'   Bestacc:'+str(best_acc_test)+'\n')
            f.close()

            if best_acc_test < mean_acc:
                best_acc_test = mean_acc
                torch.save(model.state_dict(), Log_path+'best.pth')
                torch.save(model.state_dict(), Log_path+'best.pth')


    # In[11]:


    tess_Dataloader = DataLoader(test_data, 128, shuffle=True, num_workers=8, pin_memory=True)
    model = GraphClassification(block,num_class,tras_ch).cuda()
    model.load_state_dict(torch.load(Log_path+'best.pth'))
    with torch.no_grad():
        model.eval()
        pre_classes = []
        gt_classes = []
        outputs = []
        for i,(img,label) in enumerate(tqdm(tess_Dataloader)):
            img,label = img.cuda(),label.cuda()
            pre_class =  model(img)
        #     break
            outputs = outputs + list(pre_class.detach())
            pre_classes = pre_classes + list(np.array(torch.argmax(pre_class,dim=1).detach().cpu()))
            gt_classes = gt_classes + list(np.array(label.cpu()))

        # mean_acc = OA(pre_classes, gt_classes)
        # mean_acc = round(float(mean_acc),4)
        # print(mean_acc)
        OA,AA,KAAPA, Percision_list = performance(torch.tensor(pre_classes), torch.tensor(gt_classes),num_class)
        print('OA:',round(OA,4),'AA:',round(AA,4),'KAPPA:',round(KAAPA,4),'\n', Percision_list)


    # In[12]:
    plot_confusion_matrix(gt_classes, pre_classes, range(num_class))


    # In[ ]:




