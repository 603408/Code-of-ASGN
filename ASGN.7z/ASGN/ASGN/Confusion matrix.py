#
#
# import torch
# import torchvision.transforms as transforms
# from torchvision import datasets
# from torch.utils.data import DataLoader
# import matplotlib.pyplot as plt
# from sklearn.metrics import confusion_matrix
# import numpy as np
# from train import GraphClassification  # Ensure you have the correct path to the train module
#
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# test_dir = 'data/artwork_zmh-OilPainting4/test'
#
# model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
# model.load_state_dict(torch.load('./artwork_zmh-OilPainting4/best0612--101.pth'))
# model.eval()
#
# pretrained_size = 256
# pretrained_means = [0.3980, 0.4097, 0.3696]
# pretrained_stds = [0.1468, 0.1340, 0.1303]
# test_transforms = transforms.Compose([
#     transforms.Resize(pretrained_size),
#     transforms.CenterCrop(pretrained_size),
#     transforms.ToTensor(),
#     transforms.Normalize(mean=pretrained_means, std=pretrained_stds)
# ])
#
# test_data = datasets.ImageFolder(root=test_dir, transform=test_transforms)
# test_loader = DataLoader(test_data, batch_size=64, shuffle=False)
#
# # Initialize statistics for precision, recall, and F1 score
# class_stats = {class_idx: {'total': 0, 'correct': 0, 'TP': 0, 'FP': 0, 'FN': 0} for class_idx in test_data.class_to_idx.values()}
# all_labels = []
# all_preds = []
#
# with torch.no_grad():
#     for images, labels in test_loader:
#         images, labels = images.to(device), labels.to(device)
#         outputs = model(images)
#         _, predicted = torch.max(outputs.data, 1)
#         all_labels.extend(labels.cpu().numpy())
#         all_preds.extend(predicted.cpu().numpy())
#         for pred, target in zip(predicted, labels):
#             class_idx = target.item()
#             class_stats[class_idx]['total'] += 1
#             if pred == target:
#                 class_stats[class_idx]['correct'] += 1
#                 class_stats[class_idx]['TP'] += 1
#             else:
#                 class_stats[pred.item()]['FP'] += 1
#                 class_stats[class_idx]['FN'] += 1
#
# # Calculate and print precision, recall, and F1 score
# print("Metrics per class:")
# for class_idx, stats in class_stats.items():
#     precision = stats['TP'] / (stats['TP'] + stats['FP']) if stats['TP'] + stats['FP'] > 0 else 0
#     recall = stats['TP'] / (stats['TP'] + stats['FN']) if stats['TP'] + stats['FN'] > 0 else 0
#     f1 = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0
#     accuracy = stats['correct'] / stats['total'] * 100 if stats['total'] > 0 else 0
#     print(f"Class {class_idx}: Accuracy: {accuracy:.2f}%, Precision: {precision:.2f}, Recall: {recall:.2f}, F1 Score: {f1:.2f}")
#
# # Overall metrics
# total_TP = sum(stat['TP'] for stat in class_stats.values())
# total_FP = sum(stat['FP'] for stat in class_stats.values())
# total_FN = sum(stat['FN'] for stat in class_stats.values())
# total_correct = sum(stat['correct'] for stat in class_stats.values())
# total_samples = sum(stat['total'] for stat in class_stats.values())
#
# overall_precision = total_TP / (total_TP + total_FP) if total_TP + total_FP > 0 else 0
# overall_recall = total_TP / (total_TP + total_FN) if total_TP + total_FN > 0 else 0
# overall_f1 = 2 * overall_precision * overall_recall / (overall_precision + overall_recall) if overall_precision + overall_recall > 0 else 0
# overall_accuracy = 100 * total_correct / total_samples if total_samples > 0 else 0
#
# print(f'Overall Metrics - Accuracy: {overall_accuracy:.2f}%, Precision: {overall_precision:.4f}, Recall: {overall_recall:.4f}, F1 Score: {overall_f1:.4f}')
#
# # Plot confusion matrix
# def plot_confusion_matrix(y_true, y_pred, classes, vmax_blue=200, vmax_red=20):
#     cm = confusion_matrix(y_true, y_pred)
#     fig, ax = plt.subplots(figsize=(10, 8))
#
#     # 绘制蓝色色系的对角线和零值
#     mask = np.zeros_like(cm, dtype=bool)
#     np.fill_diagonal(mask, True)
#     mask |= (cm == 0)
#
#     cm_blue = np.ma.masked_where(~mask, cm)
#     cax_blue = ax.matshow(cm_blue, cmap=plt.cm.Blues, vmax=vmax_blue)
#
#     # 添加颜色条
#     fig.colorbar(cax_blue, ax=ax, fraction=0.046, pad=0.04)
#
#     # 绘制红色色系的非对角线非零值
#     cm_red = np.ma.masked_where(mask, cm)
#     cax_red = ax.matshow(cm_red, cmap=plt.cm.Reds, vmax=vmax_red, alpha=0.7)
#
#     # 添加红色比例尺，分段为整数
#     cbar_red = fig.colorbar(cax_red, ax=ax, fraction=0.046, pad=0.04, ticks=np.arange(0, vmax_red + 1, 1))
#
#     # 添加文本标签
#     for (i, j), val in np.ndenumerate(cm):
#         color = 'black'
#         alpha = 0.3 if val == 0 else 1.0
#         ax.text(j, i, f'{val}', ha='center', va='center', color=color, alpha=alpha)
#
#     ax.set_xticks(np.arange(len(classes)))
#     ax.set_yticks(np.arange(len(classes)))
#     ax.set_xticklabels(classes)
#     ax.set_yticklabels(classes)
#     plt.xlabel('Predicted')
#     plt.ylabel('Actual')
#     plt.title('Confusion Matrix')
#     plt.show()
#
# # Get class names
# class_names = [k for k, v in sorted(test_data.class_to_idx.items(), key=lambda item: item[1])]
# plot_confusion_matrix(all_labels, all_preds, class_names)


import torch
import torchvision.transforms as transforms
from torchvision import datasets
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import numpy as np
from train import GraphClassification  # Ensure you have the correct path to the train module

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
test_dir = 'data/artwork_zmh-OilPainting4/test'

model = GraphClassification(block_num=10, labelnum=22, channel_num=100).to(device)
model.load_state_dict(torch.load('./artwork_zmh-OilPainting4/best0612--101.pth'))
model.eval()

pretrained_size = 256
pretrained_means = [0.3980, 0.4097, 0.3696]
pretrained_stds = [0.1468, 0.1340, 0.1303]
test_transforms = transforms.Compose([
    transforms.Resize(pretrained_size),
    transforms.CenterCrop(pretrained_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=pretrained_means, std=pretrained_stds)
])

test_data = datasets.ImageFolder(root=test_dir, transform=test_transforms)
test_loader = DataLoader(test_data, batch_size=64, shuffle=False)

# Initialize statistics for precision, recall, and F1 score
class_stats = {class_idx: {'total': 0, 'correct': 0, 'TP': 0, 'FP': 0, 'FN': 0} for class_idx in test_data.class_to_idx.values()}
all_labels = []
all_preds = []

with torch.no_grad():
    for images, labels in test_loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)
        all_labels.extend(labels.cpu().numpy())
        all_preds.extend(predicted.cpu().numpy())
        for pred, target in zip(predicted, labels):
            class_idx = target.item()
            class_stats[class_idx]['total'] += 1
            if pred == target:
                class_stats[class_idx]['correct'] += 1
                class_stats[class_idx]['TP'] += 1
            else:
                class_stats[pred.item()]['FP'] += 1
                class_stats[class_idx]['FN'] += 1

# Calculate and print precision, recall, and F1 score
print("Metrics per class:")
for class_idx, stats in class_stats.items():
    precision = stats['TP'] / (stats['TP'] + stats['FP']) if stats['TP'] + stats['FP'] > 0 else 0
    recall = stats['TP'] / (stats['TP'] + stats['FN']) if stats['TP'] + stats['FN'] > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0
    accuracy = stats['correct'] / stats['total'] * 100 if stats['total'] > 0 else 0
    print(f"Class {class_idx}: Accuracy: {accuracy:.2f}%, Precision: {precision:.2f}, Recall: {recall:.2f}, F1 Score: {f1:.2f}")

# Overall metrics
total_TP = sum(stat['TP'] for stat in class_stats.values())
total_FP = sum(stat['FP'] for stat in class_stats.values())
total_FN = sum(stat['FN'] for stat in class_stats.values())
total_correct = sum(stat['correct'] for stat in class_stats.values())
total_samples = sum(stat['total'] for stat in class_stats.values())

overall_precision = total_TP / (total_TP + total_FP) if total_TP + total_FP > 0 else 0
overall_recall = total_TP / (total_TP + total_FN) if total_TP + total_FN > 0 else 0
overall_f1 = 2 * overall_precision * overall_recall / (overall_precision + overall_recall) if overall_precision + overall_recall > 0 else 0
overall_accuracy = 100 * total_correct / total_samples if total_samples > 0 else 0

print(f'Overall Metrics - Accuracy: {overall_accuracy:.2f}%, Precision: {overall_precision:.4f}, Recall: {overall_recall:.4f}, F1 Score: {overall_f1:.4f}')

# Plot confusion matrix
def plot_confusion_matrix(y_true, y_pred, classes, vmax_blue=200, vmax_red=20):
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(10, 8))

    # 绘制蓝色色系的对角线和零值
    mask = np.zeros_like(cm, dtype=bool)
    np.fill_diagonal(mask, True)
    mask |= (cm == 0)

    cm_blue = np.ma.masked_where(~mask, cm)
    cax_blue = ax.matshow(cm_blue, cmap=plt.cm.Blues, vmax=vmax_blue)

    # 添加颜色条
    fig.colorbar(cax_blue, ax=ax, fraction=0.046, pad=0.04)

    # 绘制红色色系的非对角线非零值
    cm_red = np.ma.masked_where(mask, cm)
    cax_red = ax.matshow(cm_red, cmap=plt.cm.Reds, vmax=vmax_red, alpha=0.7)

    # 添加红色比例尺，分段为整数
    cbar_red = fig.colorbar(cax_red, ax=ax, fraction=0.046, pad=0.04, ticks=np.arange(0, vmax_red + 1, 1))

    # 添加文本标签
    for (i, j), val in np.ndenumerate(cm):
        color = 'black'
        alpha = 0.3 if val == 0 else 1.0
        ax.text(j, i, f'{val}', ha='center', va='center', color=color, alpha=alpha)

    ax.set_xticks(np.arange(len(classes)))
    ax.set_yticks(np.arange(len(classes)))
    ax.set_xticklabels(classes)
    ax.set_yticklabels(classes)
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')
    plt.show()

# Get class names
class_names = [k for k, v in sorted(test_data.class_to_idx.items(), key=lambda item: item[1])]
class_names.sort(key=lambda x: int(x))  # Sort class names numerically
plot_confusion_matrix(all_labels, all_preds, class_names)
